import math
import cv2
import cv2.aruco as aruco
import numpy as np

id_to_find = 5  # o id do marcador
marker_size = 15  # o tamanho do marcador em centimetros

# Verificar se a matrix é valida (internet)
def isRotationMatrix(R):
    Rt = np.transpose(R)
    shouldBeIdentity = np.dot(Rt, R)
    I = np.identity(3, dtype=R.dtype)
    n = np.linalg.norm(I - shouldBeIdentity)
    return n < 1e-6


# Calculo de rotação da matrix pelo numeros de euler (internet) // Resultado é dado na mesma ordem do MATLAB
def rotationMatrixToEulerAngles(R):
    assert (isRotationMatrix(R))

    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])

    singular = sy < 1e-6

    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0

    return np.array([x, y, z])


# Calibração
calib_path = ""
camera_matrix = np.loadtxt(calib_path + 'exemplo de matrix.txt', delimiter=',')
camera_distortion = np.loadtxt(calib_path + 'Exemplo de distorcao.txt', delimiter=',')

# rotacao da matrix em 180 no eixo x (Devido aos y e z do marcador aruco ficar invertido em relaçao ao y e z da camera)
R_flip = np.zeros((3, 3), dtype=np.float32)
R_flip[0, 0] = 1.0
R_flip[1, 1] = -1.0
R_flip[2, 2] = -1.0

# Rz(90)
R_tp = np.zeros((3, 3), dtype=np.float32)
R_tp[0, 1] = 1.0
R_tp[1, 0] = 1.0
R_tp[2, 2] = -1.0

# definindo o dicionario
aruco_dict = aruco.Dictionary_get(aruco.DICT_4X4_250)
parameters = aruco.DetectorParameters_create()

# capturando a imagem da camera
cap = cv2.VideoCapture(0)

# Difinindo o tamanho da camera
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Fonte para o texto (impresso na imagem)
font = cv2.FONT_HERSHEY_PLAIN

first_time_seen = True
n_points = 0
points = []
ponto_est = np.array([[0.0],[0.0],[0.0]])

while True:
    # Leitura do frame
    ret, frame = cap.read()

    # convertendo para escala de cinza
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # lembrando que no OpenCV as imagens sao salvas em RGB

    # Encontrar todos os marcados aruco da imagem
    corners, ids, rejected = aruco.detectMarkers(image=gray, dictionary=aruco_dict, parameters=parameters, cameraMatrix=camera_matrix, distCoeff=camera_distortion)
        
    if ids is not None:# and ids[0] == id_to_find:
        # -- ret = [rvec, tvec, ?]
        ret = aruco.estimatePoseSingleMarkers(corners, marker_size, camera_matrix, camera_distortion)
        
        # Separando a primeira saida
        rvec, tvec = ret[0][0, 0, :], ret[1][0, 0, :]
        
        # Obtendo a tag de rotação
        #R_tc = np.matmul(np.matrix(cv2.Rodrigues(rvec)[0]),R_flip)
        R_ct = np.matrix(cv2.Rodrigues(rvec)[0])  # R(-theta)
        T_ct = np.matrix(tvec).T                  # o2 = posicao do padrao na camera
        
        # Pegando as atitude em termos do euler 321 (precisa ser invertido primeiro)
        #roll_marker, pitch_marker, yaw_marker = rotationMatrixToEulerAngles(np.dot(R_tp,R_ct.T).T)
        roll_marker, pitch_marker, yaw_marker = rotationMatrixToEulerAngles(R_ct.T)
        
        # Salvando a transformação do primeiro frame
        if first_time_seen == True:
            R_tc1 = R_ct.T
            T_tc1 = -np.dot(R_tc1,T_ct)
            yaw_marker1 = yaw_marker
            print(R_tc1)
            print(T_tc1)
            print(math.degrees(yaw_marker1))
            first_time_seen = False
        
        # Descobrindo o Yaw referente a primeira posicao
        roll_marker, pitch_marker, yaw_marker = rotationMatrixToEulerAngles(np.dot(R_tc1,R_ct))

        # Desenhando o marcador
        aruco.drawDetectedMarkers(frame, corners)
        aruco.drawAxis(frame, camera_matrix, camera_distortion, rvec, tvec, 100)
        aruco.drawAxis(frame, camera_matrix, camera_distortion, R_tc1, T_tc1, 100)

        # Printar a posição na tela
        str_position = "MARKER Position x=%4.0f  y=%4.0f  z=%4.0f" % (tvec[0]/10.0, tvec[1]/10.0, tvec[2]/10.0)
        #str_position = "MARKER Position x=%4.0f  y=%4.0f  z=%4.0f" % ((tvec[0]-T_tc1[0]) / 10.0, (tvec[1]-T_tc1[1]) / 10.0, (tvec[2]-T_tc1[2]) / 10.0)#Printando a diferença entre eles
        cv2.putText(frame, str_position, (0, 100), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

        # Printando a altura do marcador referente a camera
        str_attitude = "MARKER Attitude r=%4.0f  p=%4.0f  y=%4.0f" % (
            math.degrees(roll_marker), math.degrees(pitch_marker),
            math.degrees(yaw_marker))
        cv2.putText(frame, str_attitude, (0, 150), font, 1, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Print teste
        ponto = np.dot(R_tc1,T_ct) + T_tc1
        points.append(ponto)
        n_points = n_points + 1
        if n_points == 10:
            ponto_est = np.mean(np.asarray(points),0)
            points = []
            n_points = 0
        print(ponto_est)
        print("YAW: ",math.degrees(yaw_marker1-yaw_marker))
        print("YAW: ",math.degrees(yaw_marker-yaw_marker1))
        print("YAW: ",math.degrees(yaw_marker))

    # Frame da tela
    cv2.imshow('frame', frame)

    # fechar o programa apertando
    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        cap.release()
        cv2.destroyAllWindows()
        break

